//Shakila Samaradiwakara 8886070

//Jquery event handler method
$("#registrationButton").click(function (evt) {
    window.location.href = "register.html";

})


//Jquery event handler method
$("#quoteButton").click(function (evt) {
    window.location.href = "quote.html";

})


//Jquery event handler method
$("#quizButton").click(function (evt) {
    window.location.href = "quiz.html";

})